﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;


namespace TrafficSignRecognize_v2
{
    public partial class Form2 : Form
    {
        public List<string> validPorts;
        public int cnt = 0;

        public Form2()
        {
            InitializeComponent();    
            string s2;
            //绝对路径
            string s1 = AppDomain.CurrentDomain.BaseDirectory + "交通标志集\\";
            int tmp = 1;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox1.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox2.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox3.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox4.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox5.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox6.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox7.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox8.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox9.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox10.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox11.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox12.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox13.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox14.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox15.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox16.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox17.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox18.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox19.Load(s2);
            tmp++;
            s2 = s1 + tmp.ToString() + ".png";
            this.pictureBox20.Load(s2);

            validPorts = new List<string>();
            string[] ports = SerialPort.GetPortNames();
            Array.Sort(ports);
            foreach (string port in ports)
            {
                try
                {
                    SerialPort comm = new SerialPort();
                    comm.PortName = port;
                    comm.Open();
                    comm.Close();
                    validPorts.Add(port);
                    comboBox1.Items.Insert(cnt++, port);
                }
                catch
                {
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (cnt <= 0)
            {
                MessageBox.Show("无可用串口！！");
                return;
            }

            int SelectedIndex;
            SelectedIndex = comboBox1.SelectedIndex;
            Form1.serialPort1 = new SerialPort();
            Form1.serialPort1.PortName = validPorts[SelectedIndex];
            Form1.serialPort1.BaudRate = 115200;//波特率
            Form1.serialPort1.Parity = Parity.None;//无奇偶校验位
            Form1.serialPort1.StopBits = StopBits.One;//1个停止位
            Form1.serialPort1.Handshake = Handshake.None;//控制协议
            Form1.serialPort1.ReceivedBytesThreshold = 4;//设置 DataReceived 事件发生前内部输入缓冲区中的字节数,我这里是13字节为一组
            Form1.serialPort1.Open();                 //打开串口  
            Form1.serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);   //接受数据线程
            MessageBox.Show("串口打开成功！！");
        }

        /// <summary>
        /// 监听串口数据线程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (Form1.serialPort1.IsOpen)
                {
                    byte[] readBuffer = new byte[Form1.serialPort1.ReadBufferSize + 1];
                    try
                    {
                        int count = Form1.serialPort1.Read(readBuffer, 0, Form1.serialPort1.ReadBufferSize);        //读取串口数据(监听)
                                                                                                        //String SerialIn = System.Text.Encoding.ASCII.GetString(readBuffer, 0, count); 
                        if (count != 0)
                        {
                            //将返回值byte数组转换为string类型数据
                            Form1.SerialRxByte = Encoding.Default.GetString(readBuffer);
                            Form1.Result = Form1.SerialRxByte[0];
                            if (Form1.Result>0 && Form1.Result<=10)
                            {
                                Form1.play.SoundLocation = AppDomain.CurrentDomain.BaseDirectory + "music" + Form1.Result.ToString() + ".wav";
                                Form1.play.Load();
                                Form1.play.Play(); //播放
                            }
                            Form1.RxFlag = 1;
                            //Form1.speech.Rate = 0;  //语速
                            //Form1.speech.Volume = 100;  //音量
                            //Form1.speech.SelectVoice("Microsoft Lili");//设置播音员（中文）
                            //Form1.speech.Speak("限速三十千米每小时");

                            //这里强调一下,线程里不可以直接对UI进行赋值
                            //this.BeginInvoke(new System.Threading.ThreadStart(delegate ()
                            //{
                            //    label8.Text = result;         //对控件进行赋值
                            //}));
                        }
                    }
                    catch (TimeoutException) { }
                }
                else
                {
                    TimeSpan waitTime = new TimeSpan(0, 0, 0, 0, 50);   //50ms
                    Thread.Sleep(waitTime);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int cnt = 0;
            Form1.CheckedArr = new bool[20];
            if (checkBox1.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox2.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox3.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox4.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox5.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox6.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox7.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox8.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox9.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (checkBox10.Checked)
                Form1.CheckedArr[cnt] = true;
            cnt++;
            if (Form1.serialPort1 != null)
            {
                this.Close();
            }

            else MessageBox.Show("串口未打开！！");


        }
    }


}
