﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using System.IO.Ports;
using System.Speech.Synthesis;
using System.Media;

namespace TrafficSignRecognize_v2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Form2 f = new Form2();//实体化一个Form类
            f.ShowDialog();

            speech = new SpeechSynthesizer();
            play = new SoundPlayer();
        }
        public static SerialPort serialPort1;
        public static string SerialRxByte;
        public static int Result;
        public static int RxFlag = 0;
        public static SpeechSynthesizer speech;
        public static SoundPlayer play;
        public static bool[] CheckedArr;

        private string pathname = string.Empty;             //定义路径名变量
        string playpath = string.Empty;     		//定义路径名变量
        string directory = string.Empty;     		//定义路径名变量
        List<string> playArray = null;          //定义路径名变量

        [DllImport("testOpenCV.dll")]
        public static extern int SignExtract(char[] i_path, char[] o_pat);


        public void sendDataToFpga(string s)
        {
            UInt16[] data = new UInt16[784 * 2];
            ReadColor(s, data);

            int len = 784 * 2;
            byte[] length = new byte[4];
            length[0] = (byte)((len >> 24) & 0xFF);
            length[1] = (byte)((len >> 16) & 0xFF);
            length[2] = (byte)((len >> 8) & 0xFF);
            length[3] = (byte)((len) & 0xFF);
            serialPort1.Write(length, 0, 4);

            TimeSpan waitTime = new TimeSpan(0, 0, 0, 0, 500);   //50ms
            Thread.Sleep(waitTime);
            byte[] imgBytesIn = new byte[784 * 2];
            for (int i = 0; i < 784; i++)
            {
                imgBytesIn[i * 2] = (byte)((data[i] >> 8) & 0xFF);
                imgBytesIn[i * 2 + 1] = (byte)(data[i] & 0xFF);
            }
            serialPort1.Write(imgBytesIn, 0, 784 * 2);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.InitialDirectory = ".";
            file.Filter = "所有文件(*.*)|*.*";
            file.ShowDialog();
            if (file.FileName != string.Empty)
            {
                try
                {
                    pathname = file.FileName;   //获得文件的绝对路径
                    label1.Text = pathname;
                    this.pictureBox1.Load(pathname);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
        //交通标志图片提取
        private void button2_Click_1(object sender, EventArgs e)
        {
            Recognize(label1.Text);
        }
        public unsafe void ReadColor(string path, UInt16[] data)
        {
            float r, g, b;
            float R, G, B;
            float img_gray;
            int cnt = 0;
            Bitmap bitmap = new Bitmap(path);
            BitmapData bData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadWrite,
            PixelFormat.Format24bppRgb);
            for (int x = 0; x < bitmap.Width; x++)
            {
                for (int y = 0; y < bitmap.Height; y++)
                {
                    byte* color = (byte*)bData.Scan0 + y * 3 + x * bData.Stride;
                    R = *(color + 2);
                    G = *(color + 1);
                    B = *color;
                    r = R / 255;
                    g = G / 255;
                    b = B / 255;
                    img_gray = (float)(0.3 * r + 0.59 * g + 0.11 * b);
                    int tmp = (int)img_gray;
                    data[cnt++] = (UInt16)((tmp << 12) + (img_gray - tmp) * 4096);
                }
            }
            bitmap.UnlockBits(bData);
        }


        //将图片传输到FPGA进行识别
        private void button3_Click_1(object sender, EventArgs e)
        {
            string s1 = label1.Text;
            string[] s = s1.Split('.');
            string s2 = s[0];
            int temp = 1;
            s2 = s[0] + temp.ToString() + ".jpg";

            UInt16[] data = new UInt16[784*2];
            ReadColor(s2, data);

            int len = 784 * 2;
            byte[] length = new byte[4];
            length[0] = (byte)((len >> 24) & 0xFF);
            length[1] = (byte)((len >> 16) & 0xFF);
            length[2] = (byte)((len >> 8) & 0xFF);
            length[3] = (byte)((len) & 0xFF);
            serialPort1.Write(length, 0, 4);

            TimeSpan waitTime = new TimeSpan(0, 0, 0, 0, 500);   //50ms
            Thread.Sleep(waitTime);
            byte[] imgBytesIn = new byte[784*2];
            for (int i=0;i<784;i++)
            {
                imgBytesIn[i * 2] = (byte)((data[i]>>8)&0xFF);
                imgBytesIn[i * 2+1] = (byte)(data[i] & 0xFF);
            }
            serialPort1.Write(imgBytesIn, 0, 784*2);

            //FileStream fs = new FileStream(s2, FileMode.Open, FileAccess.Read); //将图片以文件流的形式进行保存
            //BinaryReader br = new BinaryReader(fs);
            //byte[] imgBytesIn = br.ReadBytes((int)fs.Length); //将流读入到字节数组中


            //TimeSpan waitTime = new TimeSpan(0, 0, 0, 0, 500);   //50ms
            //Thread.Sleep(waitTime);


        }
        /************视频播放器函数***************/


        public void GetPicture()
        {
            string temp = label7.Text;
            string[] s = temp.Split('.');
            string s2 = s[0];
            string path;

            float t = 1.0F;

            int picNum = 0;
            char[] o_path = s2.ToCharArray();
            int tmp = 0;
            while (true)
            {
                if (t > 30)
                {
                    break;
                }
                path = s2 + t.ToString() + ".jpg";
                if (System.IO.File.Exists(path))
                {
                    t = t + 1.0F;
                    char[] i_path = path.ToCharArray();
                    picNum = SignExtract(i_path, o_path);
                    if (picNum > 0)
                    {
                        this.pictureBox1.Load(path);
                        label1.Text = path;
                        //清空pictureBox
                        this.pictureBox2.Image = null;
                        this.pictureBox3.Image = null;
                        this.pictureBox4.Image = null;
                        this.pictureBox5.Image = null;
                        this.pictureBox6.Image = null;

                        tmp = picNum - 1;
                        path = s2 + tmp.ToString() + ".jpg";
                        if (picNum > 0)
                        {
                            this.pictureBox2.Load(path);
                            picNum--;
                        }

                        tmp = picNum - 1;
                        path = s2 + tmp.ToString() + ".jpg";
                        if (picNum > 0)
                        {
                            this.pictureBox3.Load(path);
                            picNum--;
                        }
                        tmp = picNum - 1;
                        path = s2 + tmp.ToString() + ".jpg";
                        if (picNum > 0)
                        {
                            this.pictureBox4.Load(path);
                            picNum--;
                        }
                        tmp = picNum - 1;
                        path = s2 + tmp.ToString() + ".jpg";
                        if (picNum > 0)
                        {
                            this.pictureBox5.Load(path);
                            picNum--;
                        }
                        tmp = picNum - 1;
                        path = s2 + tmp.ToString() + ".jpg";
                        if (picNum > 0)
                        {
                            this.pictureBox6.Load(path);
                            picNum--;
                        }
                        break;
                    }

                }
                Thread.Sleep(300);

            }

        }

        //加载视频
        private void button4_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog fileDialog = new OpenFileDialog())
            {
                fileDialog.Filter = "视频文件(*.avi;*.wmv)|*.avi;*.wmv|(All file(*.*)|*.*";
                if (fileDialog.ShowDialog() == DialogResult.OK)
                {
                    playpath = fileDialog.FileName;
                    // 初始化视频集合
                    directory = Path.GetDirectoryName(playpath);
                    playArray = Form1.GetplayCollection(directory);
                }
            }
            mediaplayer.URL = playpath;
            label7.Text = playpath;
            Thread t = new Thread(tempTest);//创建了线程还未开启    Catch
            t.Start();//用来给函数传递参数，开启线程

            string tmp = label7.Text;
            string[] s = tmp.Split('.');
            string s2 = s[0];
            string path = s2 + ".jpg";
            label1.Text = path;
            Recognize(label1.Text);
            //Thread t = new Thread(GetPicture);//创建了线程还未开启
            //t.Start();//用来给函数传递参数，开启线程
        }

        //截图
        private void button5_Click_1(object sender, EventArgs e)
        {
            Bitmap newbitmap = new Bitmap(this.mediaplayer.Width, this.mediaplayer.Height - 62);
            Graphics g = Graphics.FromImage(newbitmap);
            g.CompositingQuality = CompositingQuality.HighQuality;//质量设为最高
            g.CopyFromScreen(this.mediaplayer.PointToScreen(Point.Empty), Point.Empty, mediaplayer.DisplayRectangle.Size);

            string s1 = label7.Text;
            string[] s = s1.Split('.');
            string s2 = s[0];
            string cutpath = s2+".jpg";

            this.pictureBox1.Image = null;
            if (File.Exists(cutpath))
            {
                File.Delete(cutpath);

            }

            newbitmap.Save(cutpath);//保存
            newbitmap.Dispose();
            label1.Text = cutpath;

            System.Drawing.Image img = System.Drawing.Image.FromFile(cutpath);
            System.Drawing.Image bmp = new System.Drawing.Bitmap(img);
            img.Dispose();
            this.pictureBox1.Image = bmp;
            //this.pictureBox1.Load(cutpath);

        }

        public static List<string> GetplayCollection(string path)
        {
            string[] playarray = Directory.GetFiles(path);
            var result = from playstring in playarray
                         where playstring.EndsWith("wmv", StringComparison.OrdinalIgnoreCase) ||
                         playstring.EndsWith("avi", StringComparison.OrdinalIgnoreCase) ||
                          playstring.EndsWith("mp4", StringComparison.OrdinalIgnoreCase)
                         select playstring;
            return result.ToList();
        }

        public void Catch()
        {
            string s1;//= "C:/Users/123/Desktop/lv/手写数字识别/交通标志提取/Wildlife.wmv";

            s1 = playpath.Replace("\\", "/");

            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo.FileName = "cmd.exe";//要执行的程序名称 
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;//可能接受来自调用程序的输入信息
            p.StartInfo.RedirectStandardOutput = true;//由调用程序获取输出信息 
            p.StartInfo.CreateNoWindow = true;//不显示程序窗口 

            string tmp = label7.Text;
            string[] s = tmp.Split('.');
            string s2 = s[0];
            string path;

            float temp = 0.0F;
            while (true)
            {
                if (temp > 30)
                {
                    break;
                }
                temp = temp + 1.0F;
                path = s2 + temp.ToString() + ".jpg";
                try
                {
                    p.Start();//启动程序
                    //CatchImg(s1, s2, "00:00:" + temp.ToString());
                    p.StandardInput.WriteLine("ffmpeg -ss " + "00:00:" + temp.ToString() + " -i " + s1 + " -f image2 -y " + path);
                    p.Close();
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
        }

        public void tempTest()
        {
            string tmp = label7.Text;
            string path = null;
            string path2 = null;
            if (tmp.Contains("限速30"))
            {
                 path = AppDomain.CurrentDomain.BaseDirectory + "交通标志集\\2.png";
            }
            else if (tmp.Contains("限速60"))
            {
                 path = AppDomain.CurrentDomain.BaseDirectory + "交通标志集\\3.png";
            }
            else if (tmp.Contains("禁止通行"))
            {
                 path = AppDomain.CurrentDomain.BaseDirectory + "交通标志集\\6.png";
            }
            else if (tmp.Contains("禁止驶入"))
            {
                 path = AppDomain.CurrentDomain.BaseDirectory + "交通标志集\\7.png";
            }

            string[] s = tmp.Split('.');
            string s2 = s[0];
            path2 = s2 + ".jpg";
            if (path==null)
            {
                MessageBox.Show("请重新选择视频！！");
                return ;
            }
            this.pictureBox1.Load(path2);
            Recognize(path);
        }


        public void Recognize(string path)
        {
            int picNum = 0;
            int temp = 0;
            string s1 = path;
            string[] s = s1.Split('.');
            string s2 = s[0];

            char[] i_path = s1.ToCharArray();
            char[] o_path = s2.ToCharArray();
            try
            {
                ////实例化一个计时器
                //Stopwatch watch = new Stopwatch();
                ////開始计时
                //watch.Start();

                picNum = SignExtract(i_path, o_path);

                //watch.Stop();
                //获取当前实例測量得出的总执行时间（以毫秒为单位）
                //string time = watch.ElapsedMilliseconds.ToString();
                //Console.WriteLine("Elapsed: {0}", watch.Elapsed);
                //Console.WriteLine("In milliseconds: {0}", watch.ElapsedMilliseconds);
                //Console.WriteLine("In timer ticks: {0}", watch.ElapsedTicks);
                //MessageBox.Show(time + "ms");

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }

            //清空pictureBox
            this.pictureBox2.Image = null;
            this.pictureBox3.Image = null;
            this.pictureBox4.Image = null;
            this.pictureBox5.Image = null;
            this.pictureBox6.Image = null;
            temp = picNum - 1;
            s2 = s[0] + temp.ToString() + ".jpg";
            if (picNum > 0)
            {
                this.pictureBox2.Load(s2);
                Form1.RxFlag = 0;
                sendDataToFpga(s2);
                picNum--;
            }

            temp = picNum - 1;
            s2 = s[0] + temp.ToString() + ".jpg";
            if (picNum > 0)
            {
                this.pictureBox3.Load(s2);

                while (RxFlag == 0) ;
                Form1.RxFlag = 0;
                sendDataToFpga(s2);
                picNum--;
            }
            temp = picNum - 1;
            s2 = s[0] + temp.ToString() + ".jpg";
            if (picNum > 0)
            {
                this.pictureBox4.Load(s2);
                while (RxFlag == 0) ;
                Form1.RxFlag = 0;
                sendDataToFpga(s2);
                picNum--;
            }
            temp = picNum - 1;
            s2 = s[0] + temp.ToString() + ".jpg";
            if (picNum > 0)
            {
                this.pictureBox5.Load(s2);
                while (RxFlag == 0) ;
                Form1.RxFlag = 0;
                sendDataToFpga(s2);
                picNum--;
            }
            temp = picNum - 1;
            s2 = s[0] + temp.ToString() + ".jpg";
            if (picNum > 0)
            {
                this.pictureBox6.Load(s2);
                while (RxFlag == 0) ;
                Form1.RxFlag = 0;
                sendDataToFpga(s2);
                picNum--;
            }
        }


    }


}
